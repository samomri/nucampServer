module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '1019166762010897',
        clientSecret: '760d7d7e7541edd1b2b9ac2cf30462f0'
    }
}